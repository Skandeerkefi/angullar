/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.html',
    './src/**/*.ts',
    './node_modules/@fortawesome/fontawesome-free/css/all.css',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

