import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ResumeListComponent } from './components/resume-list/resume-list.component';

const routes: Routes = [
  {
    path: 'resume',
    loadChildren: () =>
      import('./components/resume/resume.module').then((m) => m.ResumeModule),
  },
  { path: 'resume-list', component: ResumeListComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
