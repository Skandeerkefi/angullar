import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Resume } from 'src/app/models/Resume';

@Injectable({
  providedIn: 'root',
})
export class ResumeService {
  private baseURL = 'http://localhost:8081/resume';

  constructor(private httpClient: HttpClient) {}

  getResumeList(): Observable<Resume[]> {
    return this.httpClient.get<Resume[]>(`${this.baseURL}`);
  }

  getResumeById(id: number): Observable<Resume> {
    return this.httpClient.get<Resume>(`${this.baseURL}/${id}`);
  }

  updateResume(id: number, resume: Resume): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/${id}`, resume);
  }

  deleteResume(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
