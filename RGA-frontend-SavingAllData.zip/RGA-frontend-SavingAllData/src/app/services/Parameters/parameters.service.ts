import { Injectable } from '@angular/core';
import { Parameters } from '../../models/Parameters';
import { Section } from 'src/app/models/Section';

@Injectable({
  providedIn: 'root',
})
export class ParametersService {
  private experiences: Parameters[] = [];
  private educations: Parameters[] = [];
  private skills: Parameters[] = [];
  private sections: Section[] = []; // Add a Sections array

  constructor() {}

  addExperience(experience: Parameters): void {
    this.experiences.push(experience); // Store each entry separately
  }

  getExperiences(): Parameters[] {
    return this.experiences;
  }

  addEducation(education: Parameters): void {
    this.educations.push(education);
  }

  getEducations(): Parameters[] {
    return this.educations;
  }

  addSkill(skill: Parameters): void {
    this.skills.push(skill);
  }

  getSkills(): Parameters[] {
    return this.skills;
  }
  addSection(section: Section): void {
    this.sections.push(section); // Add a new section to the array
  }

  getSections(): Section[] {
    return this.sections;
  }
}
