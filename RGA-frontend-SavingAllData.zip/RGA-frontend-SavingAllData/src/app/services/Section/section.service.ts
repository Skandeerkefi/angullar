import { Injectable } from '@angular/core';
import { Section } from '../../models/Section';

@Injectable({
  providedIn: 'root',
})
export class SectionService {
  private sections: Section[] = [];

  addSection(section: Section) {
    this.sections.push(section);
  }

  getSections() {
    return this.sections;
  }

  getParentSection(): Section {
    const parentSection: Section = {
      name: 'ResumeDTO', // Change this name as needed
      parameters: this.sections,
    };
    return parentSection;
  }
}
