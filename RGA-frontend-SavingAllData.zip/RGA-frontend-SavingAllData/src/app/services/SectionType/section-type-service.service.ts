import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SectionType } from '../../models/SectionType';

@Injectable({
  providedIn: 'root',
})
export class ServiceTypeService {
  private sectionTypeUrl = 'http://localhost:8081/sectionType'; // Replace with your backend URL

  constructor(private httpClient: HttpClient) {}

  getSectionType(): Observable<SectionType> {
    return this.httpClient.get<SectionType>(`${this.sectionTypeUrl}`);
  }
}
