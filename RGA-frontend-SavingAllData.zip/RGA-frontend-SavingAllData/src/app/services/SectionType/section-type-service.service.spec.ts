import { TestBed } from '@angular/core/testing';

import { SectionTypeServiceService } from '../../section-type-service.service';

describe('SectionTypeServiceService', () => {
  let service: SectionTypeServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SectionTypeServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
