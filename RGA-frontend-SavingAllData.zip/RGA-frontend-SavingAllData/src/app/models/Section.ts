import {Parameters} from "./Parameters";
import {SectionType} from "./SectionType";

export interface Section {
  id?: number;
  name?: string;
  parameters?: Parameters[];
  SectionType?: SectionType;
}
