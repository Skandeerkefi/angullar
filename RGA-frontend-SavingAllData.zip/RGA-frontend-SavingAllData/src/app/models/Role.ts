export enum Role {
	Admin = 'ADMIN',
	User = 'USER',
}
