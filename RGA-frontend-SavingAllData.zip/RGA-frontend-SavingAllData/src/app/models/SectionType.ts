export interface SectionType {
	id?: number;
	type?: string;
}
