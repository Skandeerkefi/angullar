import { Resume } from './Resume';

export interface RequestResumeGeneration {
  idUser?: number;
  resume?: Resume;
}
