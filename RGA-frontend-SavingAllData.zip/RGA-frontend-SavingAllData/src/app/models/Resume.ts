import {Section} from "./Section";

export interface Resume {
  id: number;
  title: string;
  updateAt: string;
  sections: Section[];
}
