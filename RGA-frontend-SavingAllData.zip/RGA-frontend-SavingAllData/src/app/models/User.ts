import {Role} from "./Role";
import {Resume} from "./Resume";

export interface User {
	id?: number;
	email?: string;
	firstName?: string;
	lastName?: string;
	job?: string;
	type?: Role;
	resumes?: Resume[];
}
