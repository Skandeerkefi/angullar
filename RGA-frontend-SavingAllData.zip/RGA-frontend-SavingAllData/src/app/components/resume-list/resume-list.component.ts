import { Component, OnInit } from '@angular/core';
import { ResumeService } from '../../services/Resume/resume.service'; // Adjust the import path
import { Resume } from '../../models/Resume';
import { Router } from '@angular/router';


@Component({
  selector: 'app-resume-list',
  templateUrl: './resume-list.component.html',
  styleUrls: ['./resume-list.component.css'],
})
export class ResumeListComponent implements OnInit {
  resumes: Resume[] = [];

  constructor(private resumeService: ResumeService, private router: Router) {}

  ngOnInit(): void {
    this.fetchResumes();
  }

  fetchResumes(): void {
    this.resumeService.getResumeList().subscribe((resumes) => {
      this.resumes = resumes;
    });
  }

  editResume(resume: Resume): void {
    this.router.navigate(['edit-resume', resume.id]);
  }

  deleteResume(resume: Resume): void {
    const idToDelete = resume.id;
    this.resumeService.deleteResume(idToDelete).subscribe(() => {
      this.fetchResumes();
    });
  }
}
