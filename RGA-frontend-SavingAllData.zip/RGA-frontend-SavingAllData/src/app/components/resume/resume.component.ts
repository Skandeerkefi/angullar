import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Section } from '../../models/Section'; // Import the Section interface or model

@Component({
  selector: 'app-resume',
  templateUrl: './resume.component.html',
  styleUrls: ['./resume.component.css'],
})
export class ResumeComponent implements OnInit {
  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  thirdFormGroup!: FormGroup;

  counters: { [key: string]: number } = {
    experience: 0,
    education: 0,
    skills: 0,
  };

  // Define a property to store the emitted section data
  savedSections: Section[] = [];

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.initializeFormGroups();
  }

  initializeFormGroups() {
    this.firstFormGroup = this.formBuilder.group({
      firstCtrl: [''],
    });

    this.secondFormGroup = this.formBuilder.group({
      secondCtrl: [''],
    });

    this.thirdFormGroup = this.formBuilder.group({});
  }

  // Handle the emitted section data from ExperienceComponent
  handleSectionSaved(section: Section) {
    // Store the section data in the savedSections array
    this.savedSections.push(section);
    console.log('Resume', this.savedSections);
  }

  toggleSection(section: string) {
    this.counters[section]++;
  }

  generateCounterArray(section: string) {
    return new Array(this.counters[section]);
  }
}
