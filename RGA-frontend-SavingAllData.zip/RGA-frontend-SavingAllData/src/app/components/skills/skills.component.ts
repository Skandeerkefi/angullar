import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';
import { ParametersService } from '../../services/Parameters/parameters.service';
import { SectionService } from '../../services/Section/section.service';
import { Section } from '../../models/Section';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.css'],
  animations: [
    trigger('expandCollapse', [
      state(
        'collapsed',
        style({ height: '0', overflow: 'hidden', opacity: 0 })
      ),
      state('expanded', style({ height: '*', opacity: 1 })),
      transition('collapsed <=> expanded', animate('300ms ease-in')),
    ]),
  ],
})
export class SkillsComponent implements OnInit {
  @Input() skillLabel: string = '';
  @Output() sectionSaved = new EventEmitter<Section>();

  entriesForm: FormArray;

  constructor(
    private formBuilder: FormBuilder,
    private parametersService: ParametersService,
    private sectionService: SectionService
  ) {
    this.entriesForm = this.formBuilder.array([]);
  }

  ngOnInit(): void {
    this.addEntry();
  }

  addEntry(): void {
    const newEntry = this.createEntryFormGroup();
    this.entriesForm.push(newEntry);
  }

  private createEntryFormGroup(): FormGroup {
    return this.formBuilder.group({
      skill: [''],
      isExpanded: [true],
    });
  }

  toggleExpandCollapse(index: number): void {
    const entry = this.entriesForm.at(index);
    entry.patchValue({ isExpanded: !entry.get('isExpanded')?.value });
  }

  onDelete(index: number): void {
    this.entriesForm.removeAt(index);
  }

  generateSummary(entry: FormGroup): string {
    const skill = entry.get('skill')?.value;
    return `${skill}`;
  }

  onSave(entry: FormGroup, index: number): void {
    if (entry.valid) {
      entry.patchValue({ isExpanded: false });
      this.scrollToSummary(index);

      if (this.entriesForm.valid) {
        const skillData = entry.value;

        // Add the skill data to the skills array in the service
        this.parametersService.addSkill(skillData);

        // Get all skills from the service
        const allSkills = this.parametersService.getSkills();

        // Create a Section object with all skill data
        const section: Section = {
          name: 'Skills Section',
          parameters: allSkills,
        };

        // Add the section to the SectionService
        this.sectionService.addSection(section);
        this.sectionSaved.emit(section);
      }
    }
  }

  private scrollToSummary(index: number): void {
    const summaryElement = document.getElementById(`summaryField-${index}`);
    if (summaryElement) {
      summaryElement.scrollIntoView({ behavior: 'smooth' });
    }
  }

  getEntriesControls(): FormGroup[] {
    return this.entriesForm.controls as FormGroup[];
  }
}
