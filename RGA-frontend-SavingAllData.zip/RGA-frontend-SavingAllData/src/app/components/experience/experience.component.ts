import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { SectionService } from '../../services/Section/section.service';
import { Section } from '../../models/Section';
import { ServiceTypeService } from '../../services/SectionType/section-type-service.service';
import { ParametersService } from 'src/app/services/Parameters/parameters.service';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';

@Component({
  selector: 'app-experience',
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.css'],
  animations: [
    trigger('expandCollapse', [
      state(
        'collapsed',
        style({ height: '0', overflow: 'hidden', opacity: 0 })
      ),
      state('expanded', style({ height: '*', opacity: 1 })),
      transition('collapsed <=> expanded', animate('300ms ease-in')),
    ]),
  ],
})
export class ExperienceComponent implements OnInit {
  @Input() titleLabel = '';
  @Input() summaryLabel = '';
  @Input() cityLabel = '';
  @Input() descriptionLabel = '';

  @Output() sectionSaved = new EventEmitter<Section>();

  entriesForm: FormArray;

  constructor(
    private formBuilder: FormBuilder,
    private sectionService: SectionService,
    private serviceTypeService: ServiceTypeService,
    private parametersService: ParametersService
  ) {
    this.entriesForm = this.formBuilder.array([]);
  }

  ngOnInit(): void {
    this.addEntry();
  }

  addEntry(): void {
    const newEntry = this.createEntryFormGroup();
    this.entriesForm.push(newEntry);
  }

  private createEntryFormGroup(): FormGroup {
    return this.formBuilder.group({
      title: [''],
      summary: [''],
      city: [''],
      startDate: [''],
      endDate: [''],
      description: [''],
      isExpanded: [true],
    });
  }

  toggleExpandCollapse(index: number): void {
    const entry = this.entriesForm.at(index);
    entry.patchValue({ isExpanded: !entry.get('isExpanded')?.value });
  }

  onDelete(index: number): void {
    this.entriesForm.removeAt(index);
  }
  generateSummary(entry: FormGroup): string {
    const title = entry.get('title')?.value;
    const summary = entry.get('summary')?.value;
    return `Title: ${title}<br>Employee: ${summary}`;
  }

  async onSave(entry: FormGroup, index: number): Promise<void> {
    if (entry.valid) {
      entry.patchValue({ isExpanded: false });
      this.scrollToSummary(index);

      if (this.entriesForm.valid) {
        const experienceData = entry.value;
        // Add the skill data to the skills array in the service
        this.parametersService.addSkill(experienceData);

        // Get all skills from the service
        const allExperiences = this.parametersService.getSkills();
        // Add the experience data to the SectionService
        const sectionType = await this.serviceTypeService
          .getSectionType()
          .toPromise();
        const section: Section = {
          name: 'Experience Section',
          parameters: allExperiences, // Assuming you store one entry per section
          SectionType: sectionType,
        };
        this.sectionService.addSection(section);

        // Emit the section to the parent component
        this.sectionSaved.emit(section);
      }
    }
  }

  private scrollToSummary(index: number): void {
    const summaryElement = document.getElementById(`summaryField-${index}`);
    if (summaryElement) {
      summaryElement.scrollIntoView({ behavior: 'smooth' });
    }
  }

  getEntriesControls(): FormGroup[] {
    return this.entriesForm.controls as FormGroup[];
  }
}
